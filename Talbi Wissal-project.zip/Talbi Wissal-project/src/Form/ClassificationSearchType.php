<?php

namespace App\Form;

use App\Entity\Classification;
use App\Entity\ClassificationSearch;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Bridge\Doctrine\Form\Type\EntityType;
use Symfony\Component\OptionsResolver\OptionsResolver;

class ClassificationSearchType extends AbstractType
{
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('classification', EntityType::class,['class' => Classification::class,'choice_label' => 'nom' ,'label' => 'Classification' ])
        ;
    }

    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults([
            'data_class' => ClassificationSearch::class,
        ]);
    }
}
