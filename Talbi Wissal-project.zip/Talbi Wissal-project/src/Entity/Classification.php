<?php

namespace App\Entity;

use App\Repository\ClassificationRepository;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass=ClassificationRepository::class)
 */
class Classification
{
    /**
     * @ORM\Id
     * @ORM\GeneratedValue
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $nom;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $etat;

    /**
     * @ORM\OneToMany(targetEntity=Sucre::class, mappedBy="classification")
     */
    private $sucres;

    public function __construct()
    {
        $this->sucres = new ArrayCollection();
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getNom(): ?string
    {
        return $this->nom;
    }

    public function setNom(string $nom): self
    {
        $this->nom = $nom;

        return $this;
    }

    public function getEtat(): ?string
    {
        return $this->etat;
    }

    public function setEtat(string $etat): self
    {
        $this->etat = $etat;

        return $this;
    }

    /**
     * @return Collection|Sucre[]
     */
    public function getSucres(): Collection
    {
        return $this->sucres;
    }

    public function addSucre(Sucre $sucre): self
    {
        if (!$this->sucres->contains($sucre)) {
            $this->sucres[] = $sucre;
            $sucre->setClassification($this);
        }

        return $this;
    }

    public function removeSucre(Sucre $sucre): self
    {
        if ($this->sucres->removeElement($sucre)) {
            // set the owning side to null (unless already changed)
            if ($sucre->getClassification() === $this) {
                $sucre->setClassification(null);
            }
        }

        return $this;
    }
}
