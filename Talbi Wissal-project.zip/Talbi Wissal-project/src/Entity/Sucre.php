<?php

namespace App\Entity;

use App\Repository\SucreRepository;
use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Validator\Constraints as Assert;

/**
 * @ORM\Entity(repositoryClass=SucreRepository::class)
 */
class Sucre
{
    /**
     * @ORM\Id
     * @ORM\GeneratedValue
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\Column(type="string", length=255)
     *  @Assert\Length(
        * min = 4,
        * max = 30,
        * minMessage = "Nom du Sucré doit comporter au moins {{ limit }} caractères",
        * maxMessage = "Nom du Sucré doit comporter au plus {{ limit }} caractères"
        * )
     */
    private $nom;

    /**
     * @ORM\Column(type="string", length=255)
     * @Assert\Length(
        * min = 4,
        * max = 30,
        * minMessage = "Gout du Sucré doit comporter au moins {{ limit }} caractères",
        * maxMessage = "Gout du Sucré doit comporter au plus {{ limit }} caractères"
        * )
     */
    private $gout;

    /**
     * @ORM\Column(type="decimal", precision=10, scale=0)
     * @Assert\NotNull
     */
    private $prix;

    /**
     * @ORM\Column(type="string", length=255)
     * @Assert\Type("string")
     */
    private $theme;

    /**
     * @ORM\ManyToOne(targetEntity=Classification::class, inversedBy="sucres")
     */
    private $classification;

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getNom(): ?string
    {
        return $this->nom;
    }

    public function setNom(string $nom): self
    {
        $this->nom = $nom;

        return $this;
    }

    public function getGout(): ?string
    {
        return $this->gout;
    }

    public function setGout(string $gout): self
    {
        $this->gout = $gout;

        return $this;
    }

    public function getPrix(): ?string
    {
        return $this->prix;
    }

    public function setPrix(string $prix): self
    {
        $this->prix = $prix;

        return $this;
    }

    public function getTheme(): ?string
    {
        return $this->theme;
    }

    public function setTheme(string $theme): self
    {
        $this->theme = $theme;

        return $this;
    }

    public function getClassification(): ?Classification
    {
        return $this->classification;
    }

    public function setClassification(?Classification $classification): self
    {
        $this->classification = $classification;

        return $this;
    }
}
