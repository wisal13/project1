<?php

namespace App\Entity;

use App\Entity\Classification;
use Doctrine\ORM\Mapping as ORM;

class ClassificationSearch
{

    /**
     * @ORM\ManyToOne(targetEntity="App\Entity\Classification")
     */
    private $classification;


    public function getClassification(): ?Classification
    {
        return $this->classification;
    }

    public function setClassification(?Classification $classification): self
    {
        $this->classification = $classification;

        return $this;
    }



}