<?php
namespace App\Controller;

use App\Entity\Sucre;
use App\Form\SucreType;
use App\Entity\PriceSearch;
use App\Form\PriceSearchType;

use Sensio\Bundle\FrameworkExtraBundle\Configuration\IsGranted;
use App\Entity\Classification;
use App\Entity\PropertySearch;
use App\Form\ClassificationType;
use App\Form\PropertySearchType;
use App\Entity\ClassificationSearch;
use App\Form\ClassificationSearchType;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\Extension\Core\Type\NumberType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Method;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;

class IndexController extends AbstractController
{

  /**
     * @Route("/suc_prix/", name="sucre_par_prix")
     * Method({"GET"})
     */
    public function sucresParPrix(Request $request)
    {
     
      $priceSearch = new PriceSearch();
      $form = $this->createForm(PriceSearchType::class,$priceSearch);
      $form->handleRequest($request);

      $Sucrés= [];

      if($form->isSubmitted() && $form->isValid()) {
        $minPrice = $priceSearch->getMinPrice(); 
        $maxPrice = $priceSearch->getMaxPrice();
          
        $Sucrés= $this->getDoctrine()->getRepository(Sucre::class)->findByPriceRange($minPrice,$maxPrice);
    }

    return  $this->render('sucres/sucresParPrix.html.twig',[ 'form' =>$form->createView(), 'Sucrés' => $Sucrés]);  
  }

     /**
         *@Route("/",name="sucre_list")
        */
    public function home(Request $request)
    {
      $propertySearch = new PropertySearch();
      $form = $this->createForm(PropertySearchType::class,$propertySearch);
      $form->handleRequest($request);
        $Sucrés= [];

        if($form->isSubmitted() && $form->isValid()) {
            $nom = $propertySearch->getNom(); 
          if ($nom!="")
            $Sucrés= $this->getDoctrine()->getRepository(Sucre::class)->findBy(['nom' => $nom] );
          else
           $Sucrés= $this->getDoctrine()->getRepository(Sucre::class)->findAll();
        }

            return $this->render('sucres/index.html.twig',['form' =>$form->createView(), 'Sucrés'=> $Sucrés]);
    }

        /**
     * @Route("/sucre/save")
     */
    public function save() {
        $entityManager = $this->getDoctrine()->getManager();
        $Sucré = new Sucre();
        $Sucré->setNom('Mini gateau');
        $Sucré->setGout('Noisette');
        $Sucré->setPrix(1500);
        $Sucré->setTheme('Soiré');
        
        $entityManager->persist($Sucré);
        $entityManager->flush();
        return new Response('Sucré enregisté avec id '.$Sucré->getId());
        }

      /**
       * @IsGranted("ROLE_EDITOR")
       * @Route("/sucre/new", name="new_sucre")
       * Method({"GET", "POST"})
       */
    public function new(Request $request) {
        $Sucré = new Sucre();
        $form = $this->createForm(SucreType::class,$Sucré);
        $form->handleRequest($request);

        if($form->isSubmitted() && $form->isValid()) {
          $Sucré = $form->getData();
          $entityManager = $this->getDoctrine()->getManager();
          $entityManager->persist($Sucré);
          $entityManager->flush();
        return $this->redirectToRoute('sucre_list');
        }
        return $this->render('sucres/new.html.twig',['form' => $form->createView()]);
    }

       /**
     * @Route("/sucre/{id}", name="sucre_show")
     */
    public function show($id) {
        $Sucré = $this->getDoctrine()->getRepository(Sucre::class)->find($id);
  
        return $this->render('sucres/show.html.twig', array('Sucré' => $Sucré));
      }

       /**
       * @IsGranted("ROLE_EDITOR")
       * @Route("/sucre/edit/{id}", name="edit_sucre")
       * Method({"GET", "POST"})
       */

    public function edit(Request $request, $id) {
        $Sucré = new Sucre();
        $Sucré = $this->getDoctrine()->getRepository(Sucre::class)->find($id);
  
        $form = $this->createForm(SucreType::class,$Sucré);

        $form->handleRequest($request);
        if($form->isSubmitted() && $form->isValid()) {
  
          $entityManager = $this->getDoctrine()->getManager();
          $entityManager->flush();
  
          return $this->redirectToRoute('sucre_list');
        }
  
        return $this->render('sucres/edit.html.twig', ['form' => $form->createView()]);
      }
      

        /**
       * @IsGranted("ROLE_EDITOR")
       * @Route("/sucre/delete/{id}",name="delete_sucre")
       * @Method({"DELETE"})
       */
    public function delete(Request $request, $id) {
        $Sucré = $this->getDoctrine()->getRepository(Sucre::class)->find($id);
  
        $entityManager = $this->getDoctrine()->getManager();
        $entityManager->remove($Sucré);
        $entityManager->flush();
  
        $response = new Response();
        $response->send();

        return $this->redirectToRoute('sucre_list');
      }

      /**
     * @Route("/classification/newCla", name="new_classification")
     * Method({"GET", "POST"})
     */
    public function newClassification(Request $request) {
      $classification = new Classification();
    
      $form = $this->createForm(ClassificationType::class,$classification);

      $form->handleRequest($request);

      if($form->isSubmitted() && $form->isValid()) {
        $Sucré = $form->getData();

        $entityManager = $this->getDoctrine()->getManager();
        $entityManager->persist($classification);
        $entityManager->flush();
      }
      return $this->render('sucres/newClassification.html.twig',['form' => $form->createView()]);
  }

    /**
     * @Route("/suc_clas/", name="sucre_par_clas")
     * Method({"GET", "POST"})
     */
    public function sucresParClassification(Request $request) {
      $classificationSearch = new ClassificationSearch();
    
      $form = $this->createForm(ClassificationSearchType::class,$classificationSearch);
      $form->handleRequest($request);

      $Sucrés= [];

        if($form->isSubmitted() && $form->isValid()) {
            $classification = $classificationSearch->getClassification(); 

          if ($classification!="")
              $Sucrés= $classification->getSucres();
          else
              $Sucrés= $this->getDoctrine()->getRepository(Sucre::class)->findAll();
        }
      return $this->render('sucres/sucresParClassification.html.twig',['form' => $form->createView(), 'Sucrés' => $Sucrés]);
  }
  

      
      
}
